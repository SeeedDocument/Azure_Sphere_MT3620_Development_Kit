#pragma once

void GroveShield_Initialize(int* i2cFd);
