#pragma once

#include "Shield/GroveShield.h"

#include "Module/Grove4DigitDisplay.h"
#include "Module/GroveRelay.h"
#include "Module/GroveTempHumiBaroBME280.h"
#include "Module/GroveTempHumiSHT31.h"
#include "Module/GroveAD7992.h"
#include "HAL/GroveUART.h"
